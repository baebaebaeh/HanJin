package com.ssafy.exam.board.model.dao;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.exam.board.model.dto.Board;

// CRUD
/*
 * 데이터베이스 처리 기준
 * 
 * R : selectBoard(전체)
 *   : selectBoardByPK(하나조회)
 * C : insertBoard  
 * U : updateBoard  
 * D : deleteBoard  
 */
public class BoardDAOImpl implements BoardDAO {
	// 게시글 번호
	private static int boardNo;
	private static BoardDAO instance = new BoardDAOImpl();
	private BoardDAOImpl() {}
	public static BoardDAO getInstance() {
		return instance;
	}
	
	private List<Board> boardList = new ArrayList<>();
	@Override
	public void insertBoard(Board board) {
		board.setNo(++boardNo);
		boardList.add(board);
	}
	
	@Override
	public List<Board> selectBoard() {
		return boardList;
	}
	@Override
	public Board selectBoardByNo(int no) {
		for (Board b : boardList) {
			if (b.getNo() == no) {
				return b;
			}
		}
		return null;
	}
	@Override
	public void deleteBoardByNo(int no) {
		for (Board b : boardList) {
			if (b.getNo() == no) {
				boardList.remove(b);
				return;
			}
		}
		return;
	}
	@Override
	public void updateViewCnt(int no) {
		for (Board b : boardList) {
			if (b.getNo() == no) {
				b.setViewCnt(b.getViewCnt() + 1); 
				return;
			}
		}
	}
	@Override
	public void updateBoard(int no, String title, String writer, String content) {
		for (Board b : boardList) {
			if (b.getNo() == no) {
				b.setContent(content);
				b.setTitle(title);
				b.setWriter(writer);
				b.setViewCnt(0);
			}
		}
	}
}





