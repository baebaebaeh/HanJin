package com.ssafy.exam.board.model.dao;

import java.util.List;

import com.ssafy.exam.board.model.dto.Board;

public interface BoardDAO {

	void insertBoard(Board board);

	List<Board> selectBoard();

	Board selectBoardByNo(int no);

	void deleteBoardByNo(int no);

	void updateViewCnt(int no);

	void updateBoard(int no, String title, String writer, String content);

}